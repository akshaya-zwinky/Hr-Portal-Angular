export class Project{
    projectId:String="";
    projectName:string="";
    startDate:any=null;
    endDate:any=null;
    budget:number=0.0;
}